function changeContent(page) {
    const content = document.getElementById('content');
    const navLinks = document.querySelectorAll('.navbar a');

    navLinks.forEach(link => link.classList.remove('active'));

    event.target.classList.add('active');

    switch (page) {
        case 'home':
            content.innerHTML = '<h1>Добро пожаловать на мою супер крутую страницу!</h1><p>Описание страницы или какая-то другая информация.</p><a href="#" class="button" onclick="playSoundAndShowGif(); return false;">Нажми меня!</a>';
            break;
        case 'news':
            content.innerHTML = '<h1>Новости</h1><p>Здесь будут последние новости.</p>';
            break;
        case 'contacts':
            content.innerHTML = '<h1>Контакты</h1><p>Как с нами связаться.</p>';
            break;
        case 'about':
            content.innerHTML = '<h1>О нас</h1><p>Информация о нашей компании.</p>';
            break;
        case 'services':
            content.innerHTML = '<h1>Сервисы</h1><p>Описание предоставляемых нами услуг.</p>';
            break;
        default:
            content.innerHTML = '<h1>404</h1><p>Страница не найдена.</p>';
    }

    content.classList.remove('content-change-animation');
    void content.offsetWidth; // Трик для сброса анимации
    content.classList.add('content-change-animation');
}